package cn.edu.tju.simulation.cache;

import cn.edu.tju.simulation.content.SingleLocalHobby;


public interface Query {
	Boolean query(SingleLocalHobby singleContent);
}
