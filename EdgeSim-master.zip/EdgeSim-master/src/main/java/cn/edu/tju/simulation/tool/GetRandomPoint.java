package cn.edu.tju.simulation.tool;


/**
 * According to the network topology, get a random point
 * @author Wenkai Li ,School of Computer Science and Technology ,Tianjin University 
 *
 */
public class GetRandomPoint {
//	public SameWirelessNetworks BSs = Main.BSs;
	
	public void getPoint(){
		
	}
}
