package cn.edu.tju.simulation.mno;

import cn.edu.tju.simulation.cache.Cache;

/**
 * MNO
 * @author Wenkai Li ,School of Computer Science and Technology ,Tianjin University 
 *
 */
public class MobileNetworkOperator extends Cache {

}
