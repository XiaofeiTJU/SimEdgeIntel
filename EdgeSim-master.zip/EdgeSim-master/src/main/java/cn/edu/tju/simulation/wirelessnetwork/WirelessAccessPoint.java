package cn.edu.tju.simulation.wirelessnetwork;

/**
 * Hot spot < to be finished >
 * @author Wenkai Li ,School of Computer Science and Technology ,Tianjin University 
 *
 */
public class WirelessAccessPoint extends WirelessNetwork{

	@Override
	public int countUserOfNetwork() {
		// TODO Auto-generated method stub
		return 0;
	}

}
