package cn.edu.tju.simulation.algorithm;

/**
 * 
 * @author Wenkai Li ,School of Computer Science and Technology ,Tianjin University 
 *
 */
public interface OneTimeAlgorithm{
	public void setCache();
}
